import setuptools

setuptools.setup(
    name="myce",
    version="0.0.1",
    description="API definitions and client",
    url="git://github.com:rotwatsb/myce.git",
    author="Steve Bradley",
    packages=["myce"],
    license="unlicensed",
    python_requires='>=3.6',
)
